﻿using System;

namespace Server.Models
{
    public class PersonInModel
    {
        public string Name { get; set; }

        public string Class { get; set; }

        public string Building { get; set; }
    }
}

